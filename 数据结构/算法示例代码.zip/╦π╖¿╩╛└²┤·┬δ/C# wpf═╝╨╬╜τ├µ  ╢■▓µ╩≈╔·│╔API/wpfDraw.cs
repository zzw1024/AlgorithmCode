﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace WpfApplication1
{


    /*
     *
     * the class who implement this interface must be override the ToString() method
     * because the wpfDraw.print() method depend on the ToString() method;
     * 
     * 
     */
    interface ILeave
    {
        ILeave GetLeft();
        ILeave GetRight();
    }

    class wpfDraw
    {
        /*————————————————————————————————————
         * 
         * 
        //use explain

        //         canvas1 - Canvas   size(Width:1440,Height:900)

        //         this.bm = new Size(SystemParameters.PrimaryScreenWidth, SystemParameters.PrimaryScreenHeight);
        //         wpfDraw.print(this.root, (this.bm.Width - 20.0) / 2.0, 60.0, this.bm.Width / 4.0, canvas1);


        //         Invoke this function can draw the binary tree on the canvas1[Canvas]
        
         * 
         * 
         * ————————————————————————————————————*/

        public static void print(ILeave root, double x, double y, double x_add, Canvas canvas1)
        {
            if (root != null)
            {
                Label label = new Label();
                label.FontSize = 10.0;
                label.Margin = new Thickness(x - 20.0, y - 20.0, 0.0, 0.0);
                label.Content = root.ToString();
                label.Foreground = new SolidColorBrush(Colors.Black);
                canvas1.Children.Add(label);



                print(root.GetLeft(), x - x_add, y + 60.0, x_add / 2.0, canvas1);
                print(root.GetRight(), x + x_add, y + 60.0, x_add / 2.0, canvas1);
                if (root.GetLeft() != null)
                {
                    Line line = new Line();
                    line = new Line();
                    line.Stroke = Brushes.Red;
                    line.X1 = x + 10.0;
                    line.Y1 = y + 5.0;
                    line.X2 = x - x_add + 10.0;
                    line.Y2 = y + 60.0 + 5.0;
                    canvas1.Children.Add(line);
                }
                if (root.GetRight() != null)
                {
                    Line line = new Line();
                    line = new Line();
                    line.Stroke = Brushes.Red;
                    line.X1 = x + 10.0;
                    line.Y1 = y + 5.0;
                    line.X2 = x + x_add + 10.0;
                    line.Y2 = y + 60.0 + 5.0;
                    line.HorizontalAlignment = HorizontalAlignment.Left;
                    line.VerticalAlignment = VerticalAlignment.Center;
                    canvas1.Children.Add(line);
                }
            }
        }
    }
}
